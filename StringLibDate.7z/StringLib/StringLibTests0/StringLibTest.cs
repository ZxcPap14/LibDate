﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using StringLib;

namespace StringLibTests0
{
    /// <summary>
    /// Формат - Дата
    /// </summary>
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void StringLib_CorrectDate_ReturnedTrue()
        {
            string TextDate = "30.05.2006";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void StringLib_Empty_ReturnedFalse()
        {
            string TextDate = " ";
            int typeDate = 0;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void MStringLib_MagicDate_ReturnedTrue()
        {
            string TextDate = "01.01.1900";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void StringLib_UnixZero_ReturnedTrue()
        {
            string TextDate = "01.01.1970";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void StringLib_IncorrectDate1_ReturnedFalse()
        {
            string TextDate = "00.12.2023";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse (result);
        }
        [TestMethod]
        public void StringLib_IncorrectDate2_ReturnedFalse()
        {
            string TextDate = "30.02.23";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_IncorrectMonth_ReturnedFalse()
        {
            string TextDate = "12.15.2023";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_IncorrectYear_ReturnedFalse()
        {
            string TextDate = "12.15.0000";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_IncorrectLeapYear_ReturnedFalse()
        {
            string TextDate = "29.02.2023";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_ZeroInDate1_ReturnedFalse()
        {
            string TextDate = "00.00.0000";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_ZeroInDate2_ReturnedFalse()
        {
            string TextDate = "12.03.0000";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_ZeroInDate3_ReturnedFalse()
        {
            string TextDate = "12.00.1989";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_ZeroInDate4_ReturnedFalse()
        {
            string TextDate = "00.03.1989";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_MaxNumber1_ReturnedFalse()
        {
            string TextDate = "99.99.9999";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_MaxnumberinYear_ReturnedTrue()
        {
            string TextDate = "12.03.9999";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsTrue(result);
        }
        [TestMethod]
        public void StringLib_MaxNumbersInMonth_ReturnedFalse()
        {
            string TextDate = "12.99.1989";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void StringLib_MaxNumbersInDays_ReturnedFalse()
        {
            string TextDate = "99.03.1989";
            int typeDate = 10;
            //Act
            bool result = StringClass.StringParse(TextDate, typeDate);
            //Assert
            Assert.IsFalse(result);
        }


    }
}
